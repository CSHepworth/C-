﻿for (int i = 1; i <= 255; i++)
{
    Console.WriteLine(i);
}

for (int j = 1; j <= 100; j++)
{
    if ((j % 3 == 0 && j % 5 != 0) || (j % 3 != 0 && j % 5 == 0))
    {
        Console.WriteLine(j);
    }
}

for (int k = 1; k <= 100; k++)
{
    if (k % 3 == 0 && k % 5 == 0)
    {
        Console.WriteLine(k);
        Console.WriteLine("fizzbuzz");
    }
    else if (k % 3 == 0 && k % 5 != 0)
    {
        Console.WriteLine(k);
        Console.WriteLine("fizz");
    }
    else if (k % 3 != 0 && k % 5 == 0)
    {
        Console.WriteLine(k);
        Console.WriteLine("buzz");
    }
}