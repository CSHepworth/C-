﻿Human Human1 = new Human("Johnny", 7, 3, 6, 100);
Human Human2 = new Human("Terence");

Console.WriteLine(Human2.Dexterity);
