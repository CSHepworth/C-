﻿Deck deck = new Deck();

Console.WriteLine(deck);