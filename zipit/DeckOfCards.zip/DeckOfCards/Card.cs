class Card
{
    public string Name;
    public string suit;
    public int val;

    public Card(string s, int val)
    {
        switch (val)
        {
            case 11:
                Name = "Jack";
                break;
            case 12:
                Name = "Queen";
                break;
            case 13:
                Name = "King";
                break;
            case 1:
                Name = "Ace";
            default:
                Name - val.ToString();
                break;
        }
        suit = s;
        Value = val;
    }

    public override string ToString()
    {
        return $@"
        Name: {Name}
        Suit: {Suit}
        Value: {Value}";
    }
}