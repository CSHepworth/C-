﻿Buffet buffet = new Buffet();

Ninja ninja1 = new Ninja();

ninja1.Eat(buffet.Serve());
ninja1.Eat(buffet.Serve());
ninja1.Eat(buffet.Serve());